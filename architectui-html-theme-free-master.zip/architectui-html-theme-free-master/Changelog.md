### Changelog

## Version 1.0.0 (17 January 2019)

## Version 1.2.3 (19 May 2021)

- Added mapbox-gl plugin
- Alert Dismissing issue resolved
- Card image issue resolved
- Fontawesome icon issue resolved